# A1 output contract

Every action response starts with its action, brand, period, Campaign/Batch scope, and an overall status: `Draft`, `Ready for review`, `Hold`, or `Blocked`. Attach confidence labels and source references to decisions.

## Common fields

Include, when applicable:

- Campaign ID, Batch ID, Brief ID, Task ID, and Change ID (mark proposed IDs `PROVISIONAL`).
- Brand, period, objective, audience, channel, CTA, deliverable, and acceptance criteria.
- Source name/link, source owner, version/effective date, permitted-use status, and claims needing confirmation.
- Task owner, Backup operator, Reviewer, Final approver, Specialist confirmer, Technical Owner as roles; real names only from a current effective-dated assignment roster.
- Deadline, priority/reason, status, dependencies, gate/check state, budget fields, risks, missing inputs, next action, owner role, and evidence links.

## Output shapes

### Monthly plan

| Brand | Approved objective | Proposed campaign | Audience / CTA | Channel / deliverables | Planned budget | Approved ceiling | KPI / evidence | Dependencies | Approval status |
|---|---|---|---|---|---:|---:|---|---|---|

### Campaign and Batch plan

| ID | Parent | Scope / objective | Output | Source and version | Budget status | Deadline | Gate | Status |
|---|---|---|---|---|---|---|---|---|

### Task assignments

| Task ID | Agent | Action / output | Task owner | Backup | Reviewer | Approver / confirmer | Due | Priority | Dependency / status |
|---|---|---|---|---|---|---|---|---|---|

### Budget reconciliation

| Brand / Campaign / Batch | Proposed | Approved ceiling | Planned | Committed | Actual | Remaining | Utilization | Evidence / alert |
|---|---:|---:|---:|---:|---:|---:|---:|---|

### Gate and exception review

| Check / gate | Required evidence | Evidence found | Result | Decision authority | Next action / role |
|---|---|---|---|---|---|

### Performance closeout

| KPI | Approved target | Actual | Variance | Evidence/source date | Confidence | Decision |
|---|---:|---:|---:|---|---|---|

Close each response with **Cần quyết định/xác nhận**, **Việc tiếp theo**, and **Phân công vai trò**. State “chưa có dữ liệu” rather than silently omitting a required KPI or approval field.
