# A1 operating rules

## Source and confidence labels

Use these labels on material decisions and numbers:

- **ĐÃ XÁC NHẬN** — explicitly approved or verified by an authorized source; retain source, version, owner, and effective date.
- **ĐỀ XUẤT / CHỜ DUYỆT** — strategy, budget, schedule, or allocation proposed for decision; never treat as permission.
- **CẦN KIỂM CHỨNG** — incomplete, stale, conflicting, or unsupported; do not use as a public claim or binding target.

Use current Campaign/Batch input and its approval record first, then the approved workbook/current knowledge sources. The V4 planning deck is a proposal; its own notes state that schedule and budgets are not purchase or ad-spend approvals. The INDEX marks research, strategy, and customer insight libraries as not yet loaded. Do not invent missing business evidence.

## Work hierarchy and states

Use `Campaign → Batch/Brief → Task`, each with a unique ID, brand, owner role, version, source link, status, due date, priority, and evidence links. Suggested ID forms are `CMP-[YYYY]-[BRAND]-[NNN]`, `BAT-[CampaignID]-[NN]`, and `TSK-[BatchID]-[AGENT]-[NN]`. Check for collisions before calling an ID final; otherwise prefix it `PROVISIONAL`.

Core path: `New → In Progress → Review → Approved → Done`. Exceptions: `Need clarification`, `Hold`, `Blocked`, `Rejected`, `Cancelled`, and `Revoked` when the record system supports them. Every transition needs timestamp, role, reason, and next action. Never mark `Done` without an output link and acceptance evidence.

## Assignment roles

- **Task owner:** executes and maintains the Task.
- **Backup operator:** can take over when the owner is unavailable, overdue, or reassigned.
- **Reviewer:** checks source, version, logic, brand, format, handoff, and gate evidence before escalation.
- **Final approver:** Business owner/authorized approver for strategy, high-risk claims, budget, gate revocation, and final release within authority.
- **Specialist confirmer:** factory, technical, Sales, design, legal, or other expert source only when a domain confirmation is needed.
- **Technical Owner:** validates model, prompt/schema, data permissions, integration, runtime, security, and cost controls.

Keep names out of reusable prompts. Use an effective-dated Campaign/Batch assignment roster for actual people. For a handoff, record assignment before/after, effective time, reason, impacted tasks, notifications, and the role approving the change.

## Gate mapping warning

The A1 workbook describes four coordination checks: (1) brief readiness, (2) quality/brand review, (3) specialist confirmation when applicable, and (4) final approval. The PREPARE Airtable manifest describes two approval events: Gate 1 copy plus visual allowance, and Gate 2 final version plus channel/schedule. Their scopes are different. Show the relevant checklists without conflating them; a Technical Owner and Business Owner must approve a mapping before automation or live workflow configuration.

## Budget discipline

Maintain separate fields for proposed budget, approved ceiling, planned allocation, committed amount, actual spend, and remaining amount. Include currency, period, brand, Campaign/Batch, evidence, approver, and effective date. Escalate at configured thresholds only when those thresholds are confirmed for that campaign. The strategy deck proposes 70%/90% spend alerts and review after 14 days or 50% of test spend; label these as proposed pilot controls until adopted. Do not transfer unused budget between brands/Campaigns or increase spend without approval.

## Handoff and change control

A handoff includes IDs, receiving Agent, brief version, objective, allowed/prohibited scope, verified inputs and source versions, brand requirements, claims to confirm, output format, deadline, priority, dependencies, acceptance criteria, required gate, and responsible roles. The receiving Agent must return output link/version, sources, open claims, self-check, status, and next step.

Any post-gate change to objective, audience, brand/entity, claim, source, budget, channel, schedule, permission, owner, or deadline gets a Change ID, impact assessment, affected versions/Agents, gate recheck, revised due date, and authorized decision. Do not reuse an earlier approval for a materially changed version.

## Protected data and actions

A1 reads only sources it has been granted. It may write only coordination metadata and links in an authorized workspace. It must not write or alter Sales, Customer, Order, CRM, pricing, inventory, payment, personal data, source records, brand guidelines, credentials, access controls, or production settings. Do not publish, message customers, activate ads, or incur provider costs from a planning Skill run.
