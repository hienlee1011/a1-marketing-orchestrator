# A1 action menu and minimum inputs

The A1 Workbench button labels correspond to the six actions below. The Workbench creates a structured prompt/input packet; it does not call a model or write to connected systems.

## 1. Kế hoạch tháng

**Minimum input:** month/period; brand(s); approved business direction; monthly objective; approved budget or its status; available team capacity; any required dates or campaign constraints.

**Produce:** one row per brand with objective, audience, funnel stage, proposed campaign theme, CTA, channels, deliverable mix, timing, budget ceiling and allocation rationale, KPI definitions and evidence sources, dependencies, risks, assumptions, and approval status. Show both plan and approved amount separately. If no numeric KPI target is provided, recommend measurable definitions and mark numeric targets as proposed for approval.

## 2. Tạo Campaign/Batch

**Minimum input:** brand; approved monthly plan item; objective; audience or research needed; subject/product/project; CTA; channel/output types; timing; permitted sources; budget status; role assignments or a request to leave roles unassigned.

**Produce:** Campaign record, one or more Batch/Brief records, proposed IDs, task scope, deliverables, source/version requirements, claim checks, audience angle, channel-specific output requirements, acceptance criteria, dependencies, timeline, budget allocation (only within authorized ceiling), gates, and unresolved inputs. If an audience, source, CTA, or permission is missing, identify it and set the affected Brief to Hold/Need clarification.

## 3. Giao việc

**Minimum input:** Campaign/Batch/Task IDs or permission to propose provisional IDs; deliverables; deadline; dependencies; current role assignments and effective dates; A2–A9 availability/constraints if known.

**Produce:** task table with Task ID, receiving Agent, action, input links and versions, expected output, Task owner role, Backup operator role, Reviewer role, Final approver when required, Specialist confirmer when needed, deadline, priority and reason, dependency, status, acceptance criteria, and handoff payload. Do not assign a named person unless the assignment table is supplied and effective for the Task period.

## 4. Kiểm tra ngân sách

**Minimum input:** reporting period; brand/Campaign/Batch; approved ceiling and approval evidence/status; committed amounts; actual spend with source/date; allocation rules or requested scenario.

**Produce:** ceiling → planned → approved → committed → actual → remaining, with variance and utilization where calculable; brand/channel/Batch breakdown; forecast only when the method and assumptions are shown; alert status; unsupported/missing evidence; and recommendation. Label unapproved commitments as proposals. Never imply that a budget cap grants permission to spend.

## 5. Rà Gate / ngoại lệ

**Minimum input:** Campaign/Batch/Task ID; current state; current brief/source/output versions; review and approval evidence; issue/change description; responsible roles.

**Produce:** checklist by applicable gate; pass/fail/not evidenced; invalidated approvals; missing evidence; Hold/Blocked/Rejected recommendation; Change ID and impact; required reviewer/specialist/approver; next action and owner role. A passed checklist is not itself an approval or authorization to release.

## 6. Báo cáo kết quả

**Minimum input:** reporting period; Campaign/Batch IDs; targets and their approval status; actuals and evidence sources; platform data; Sales acceptance feedback; cost records; changes made during the period.

**Produce:** plan vs actual table, data coverage, source and freshness notes, performance drivers supported by evidence, unverified hypotheses separated from findings, budget status, work completed/open, accepted lead or qualified next-step counts only when Sales confirms, recommendations for the next period, and decisions needed. Do not infer revenue from views, clicks, engagement, or leads without an approved evidence link.

## Shared validation

- If any key input is missing, still return a draft where possible and list what prevents a final decision.
- Treat plan values from the strategy deck as reference proposals unless the user provides current approval evidence.
- Never fill an absent numerical target with an arbitrary “industry standard.” Propose a target-setting method and identify the approver.
- Keep LYK domestic project-lead work separate from Hilykan product/sample/RFQ/partnership work unless a combined campaign is explicitly approved.
