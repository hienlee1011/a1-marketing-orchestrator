# 2026–2027 planning baseline (proposal, not spending authority)

This is a compact reference to the 9-Agent planning deck. The deck labels the schedule, campaign themes, media amounts, and cost scenarios as internal proposals, not approved procurement or ad spend. Current user-provided approval records and current inputs take precedence.

## Business direction

- **Period proposed:** October 2026 through December 2027 (15 months), one Campaign per month per brand (30 total).
- **LYK:** prioritize domestic project-lighting leads. Desired next step: a qualified project brief, consultation, site discussion, or quote request accepted by Sales.
- **Hilykan:** prioritize suitable product/production partnership conversations, sample requests, and RFQs. Target export market is not selected in the source plan; ask for confirmation before market-specific positioning.
- **Content volume proposed per month:** LYK: one pillar article, three social posts, up to one video when verified footage/capacity are available, and two ad variants. Hilykan: one portfolio/process story, three social posts, up to one video when source footage is available, and two ad variants. Do not make these mandatory if source, budget, approval, or capacity is missing.

## Budget scenarios in the proposal

- **Facebook media cap proposed:** VND 450 million total for 15 months; LYK VND 315 million (70%), Hilykan VND 135 million (30%).
- **Quarterly media proposal:** Q4 2026 VND 75 million; Q1 2027 VND 60 million; Q2 2027 VND 90 million; Q3 2027 VND 100 million; Q4 2027 VND 125 million. Total VND 450 million.
- **Base total-system estimate proposed:** setup VND 40 million + tools VND 108 million + content production VND 180 million + Facebook media VND 450 million + 10% administration contingency VND 77.8 million = VND 855.8 million. Not all assumptions, taxes/fees, seats, agency costs, or staffing costs are confirmed.
- **Alternative scenarios proposed:** lean VND 522.5 million and expanded VND 1,270.5 million. Check the source deck before quoting the line-item assumptions.

## Measurement direction

- Separate channel signals (views, engagement, clicks) from Sales-confirmed accepted leads, opportunities, and revenue.
- No approved numeric lead, CAC, revenue, or conversion target is evidenced in the deck. A1 may recommend a target-setting exercise; it must not invent a target.
- Proposed operational controls include 100% source/version traceability, review after 14 days or 50% of test spend, and 70%/90% budget alerts. They are pilot recommendations until approved.
- A Sales-response SLA of one business day appears as a proposed control and must be confirmed by Sales before being promised.

## Use rule

If this baseline is used, label every schedule and amount **ĐỀ XUẤT / CHỜ DUYỆT** unless a separate approval record names the authorized approver, approved scope/amount, date, and effective period. Never treat the 70/30 split or a monthly allocation as permission to transfer or spend.
